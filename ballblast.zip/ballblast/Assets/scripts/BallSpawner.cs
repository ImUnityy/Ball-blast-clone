using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BallSpawner : MonoBehaviour
{
    public GameObject ballPrefab; 
    public float spawnInterval = 3f;
    public Transform[] spawnPoints;

    void Start()
    {
        InvokeRepeating("SpawnBall", 1f, spawnInterval);
    }

    void SpawnBall()
    {
        int index = Random.Range(0, spawnPoints.Length);
        Instantiate(ballPrefab, spawnPoints[index].position, Quaternion.identity);
    }
}


