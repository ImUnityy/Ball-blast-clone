using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Ball : MonoBehaviour
{
    public float bounceForce = 5f;
    public int ballSize = 3; 
     public GameObject smallerBallPrefab;

    private Rigidbody2D rb;

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();

        
        float xDirection = Random.Range(-2f, 2f);
        rb.velocity = new Vector2(xDirection, 0);
    }

    void OnCollisionEnter2D(Collision2D collision)
    {
        
        if (collision.gameObject.CompareTag("Bullet"))
        {
            Destroy(collision.gameObject); 
            
            ScoreManager.instance.AddScore(10);

            
            if (ballSize > 1)
            {
                SplitIntoSmallerBalls();
            }

            Destroy(gameObject); 
        }

        
        if (collision.gameObject.CompareTag("Player"))
        {
            GameOverManager.instance.GameOver(); 
            Destroy(collision.gameObject); 
        }
    }

    void SplitIntoSmallerBalls()
    {
        for (int i = 0; i < 2; i++)
        {
            GameObject newBall = Instantiate(smallerBallPrefab, transform.position, Quaternion.identity);

            Ball ballScript = newBall.GetComponent<Ball>();
            ballScript.ballSize = ballSize - 1;
            newBall.transform.localScale = transform.localScale * 0.7f;

            Rigidbody2D newRb = newBall.GetComponent<Rigidbody2D>();
            float direction = (i == 0) ? -2f : 2f;
            newRb.velocity = new Vector2(direction, 5f);
        }
    }
}